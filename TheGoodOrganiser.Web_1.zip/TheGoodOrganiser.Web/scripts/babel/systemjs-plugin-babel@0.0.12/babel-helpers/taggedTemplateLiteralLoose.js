export default (function (strings, raw) {
  strings.raw = raw;
  return strings;
})