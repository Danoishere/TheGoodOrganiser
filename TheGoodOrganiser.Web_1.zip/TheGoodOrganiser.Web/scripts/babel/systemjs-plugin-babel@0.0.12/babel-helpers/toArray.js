export default (function (arr) {
  return Array.isArray(arr) ? arr : Array.from(arr);
})