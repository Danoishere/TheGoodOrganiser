export default (function (obj) {
  if (obj == null) throw new TypeError("Cannot destructure undefined");
})