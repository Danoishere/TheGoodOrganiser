import {inject} from 'aurelia-framework';
import {HttpClient} from 'aurelia-fetch-client';

@inject(HttpClient)
export class StockMonitor{
    constructor(http) {
        this.http = http;
    }
}