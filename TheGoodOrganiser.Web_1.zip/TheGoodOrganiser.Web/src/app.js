﻿export class App{
    constructor(){
        this.title = "The Good Organiser";
    }
}